http://www.linuxjournal.com/article/10789



resources
http://www.talon-systems.com/mobile/jqtouch/themes/jqt/img/
